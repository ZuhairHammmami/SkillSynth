import{l as o,a as r}from"../chunks/i3kxKTNh.js";export{o as load_css,r as start};
